﻿
Lập trình ứng dụng Java
BT04 - Maven 3 Layers ORM Hibernate JPA Code First

---------------------------------------------------

1612209 - Nguyễn Hữu Hòa
SĐT	: 0982327118
Email	: 1612209@student.hcmus.edu.vn

---------------------------------------------------

Cấu trúc bài nộp:
-Demo			: Video demo
-Ref			: Tài liệu tham khảo
-Source			: Source (đã xóa thư mục target)
-SourceWithLib-Full	: Source Full (bao gồm cả thư viện)
-Readme.md		: Ghi chú

---------------------------------------------------

Các chức năng đã làm được :
CRUD cho Department (25đ)
CRUD cho Employee (25đ)
CRUD cho Project (25đ)

---------------------------------------------------

Hướng dẫn chạy :
- Mở xampp và start các dịch vụ : Apache,mysql
- Mở project
- Build with Dependencies
- Chọn trình duyệt (Embedded hoặc các trình duyệt ngoài)
- Start

---------------------------------------------------

Website		: http://localhost:8080/QLPhongBan/
Database	: MySql
		  http://localhost:81/phpmyadmin/ (port mặc định là 80 - bị skype chiếm)
user		: root
password	: (không có)
