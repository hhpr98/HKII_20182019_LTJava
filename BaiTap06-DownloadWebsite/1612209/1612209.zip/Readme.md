﻿Phát triển ứng dụng Java - CQ2016/31
-------------------------------------------------------------------

MSSV	: 1612209
Họ tên	: Nguyễn Hữu Hòa
email	: 1612209@student.hcmus.edu.vn
DĐ	: 0982327118

-------------------------------------------------------------------

Các chức năng đã làm được :
- Download site (Text & image)
- Using multithread
- Chỉnh sửa link site & image (running in localhost)

-------------------------------------------------------------------

Cách sử dụng :
Open command line
> cd [tên đường dẫn]
> java -jar DownloadWeb.jar
> Nhập URL (dạng http:// hoặc https://)
> Chương trình tự mở folder & index trên trình duyệt